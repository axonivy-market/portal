=======================================================
This guide helps you configure the Portal Error pages
=======================================================

=======================================================
Step 1: Place 2 files: "ivy-portal-404-error-page.xhtml" and "ivy-portal-500-error-page.xhtml" in "webapps\ivy" of ivy engine.
In order to use the custom error page, the given error pages need to be edited to associate with your engine's url. Please go to these pages and follow the instruction inside.
=======================================================

=======================================================
Step 2: Copy the following code snippet into your web.xml (located at "webapps\ivy\WEB-INF"). Then, restart your engine.

    <error-page>
        <error-code>404</error-code>
        <location>/faces/ivy-portal-404-error-page.xhtml</location>
    </error-page>
	<error-page>
        <error-code>500</error-code>
        <location>/faces/ivy-portal-500-error-page.xhtml</location>
    </error-page>
	<error-page>
		<exception-type>java.lang.Throwable</exception-type>
		<location>/sys/ivy-portal-500-error-page.xhtml</location>
	</error-page>
=======================================================

Note:
For Internet Explorer browser, you should turn off the default error page of the browser to see our error pages.
To turn off:
 *First, open Internet Options of the browser.
 *Second, go to Advance tab.
 *Finally: scroll down to "Browsing" section, and then uncheck "Show friendly HTTP error message", and finish the setting.
